import 'package:flutter/material.dart';
import 'package:mom_home_handoff/mom_home.dart';

void main() => runApp(const DemoApp());

class DemoApp extends StatefulWidget {
  const DemoApp({super.key});

  @override
  State<DemoApp> createState() => _DemoAppState();
}

class _DemoAppState extends State<DemoApp> {
  var state = MomHomeViewState.purchased;

  @override
  Widget build(BuildContext context) {
    final data = switch (state) {
      MomHomeViewState.initial => MomHomeData.initial(),
      MomHomeViewState.recorded => MomHomeData.recorded(),
      MomHomeViewState.purchased => MomHomeData.purchased(),
    };
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: MomHomeTheme.build(),
      home: Stack(
        children: [
          MomHomeScreen(data: data),
          Positioned(
            top: 8,
            right: 8,
            child: SafeArea(
              child: PopupMenuButton<MomHomeViewState>(
                icon: const Icon(Icons.layers_outlined, size: 20),
                onSelected: (value) => setState(() => state = value),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: MomHomeViewState.initial, child: Text('初始态')),
                  PopupMenuItem(value: MomHomeViewState.recorded, child: Text('有数据态')),
                  PopupMenuItem(value: MomHomeViewState.purchased, child: Text('已购服务态')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
