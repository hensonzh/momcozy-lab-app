import 'package:flutter/material.dart';

abstract final class MomHomeColors {
  static const background = Color(0xFFFBF8F4);
  static const surface = Color(0xFFFFFDFC);
  static const textPrimary = Color(0xFF2B2826);
  static const textSecondary = Color(0xFF776E69);
  static const textMuted = Color(0xFF958A84);
  static const rose = Color(0xFFB94C77);
  static const roseDeep = Color(0xFF8A607F);
  static const roseSoft = Color(0xFFF7E7E7);
  static const blush = Color(0xFFFFEDEA);
  static const lilac = Color(0xFFEADAF8);
  static const cream = Color(0xFFF6EFE3);
  static const mint = Color(0xFFE8F3EF);
  static const teal = Color(0xFF3E7180);
  static const border = Color(0xFFE9E1DC);
}

abstract final class MomHomeRadii {
  static const card = 22.0;
  static const compactCard = 20.0;
  static const button = 18.0;
  static const pill = 999.0;
}

abstract final class MomHomeSpacing {
  static const page = 16.0;
  static const section = 14.0;
  static const card = 16.0;
  static const compact = 8.0;
}

class MomHomeTheme {
  const MomHomeTheme._();

  static ThemeData build() => ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: MomHomeColors.background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: MomHomeColors.rose,
          surface: MomHomeColors.surface,
        ),
        textTheme: const TextTheme(
          headlineSmall: TextStyle(
            fontFamily: 'Noto Sans SC',
            fontFamilyFallback: ['PingFang SC', 'sans-serif'],
            fontSize: 22,
            height: 1.35,
            fontWeight: FontWeight.w700,
            color: MomHomeColors.textPrimary,
          ),
          titleLarge: TextStyle(
            fontFamily: 'Noto Sans SC',
            fontFamilyFallback: ['PingFang SC', 'sans-serif'],
            fontSize: 18,
            height: 1.35,
            fontWeight: FontWeight.w700,
            color: MomHomeColors.textPrimary,
          ),
          titleMedium: TextStyle(
            fontFamily: 'Noto Sans SC',
            fontFamilyFallback: ['PingFang SC', 'sans-serif'],
            fontSize: 15,
            height: 1.35,
            fontWeight: FontWeight.w600,
            color: MomHomeColors.textPrimary,
          ),
          bodyMedium: TextStyle(
            fontFamily: 'Noto Sans SC',
            fontFamilyFallback: ['PingFang SC', 'sans-serif'],
            fontSize: 12,
            height: 1.55,
            color: MomHomeColors.textSecondary,
          ),
          bodySmall: TextStyle(
            fontFamily: 'Noto Sans SC',
            fontFamilyFallback: ['PingFang SC', 'sans-serif'],
            fontSize: 10,
            height: 1.45,
            color: MomHomeColors.textMuted,
          ),
        ),
      );
}
