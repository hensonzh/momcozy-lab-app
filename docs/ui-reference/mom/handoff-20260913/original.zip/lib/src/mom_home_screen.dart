import 'package:flutter/material.dart';

import 'mom_home_models.dart';
import 'mom_home_theme.dart';

abstract final class _Assets {
  static const cozymateAvatar = 'assets/images/cozymate_avatar.png';
  static const expertGroup = 'assets/images/expert_group.png';
  static const ibclcJamie = 'assets/images/ibclc_jamie_lee.png';
  static const aiBlush = 'assets/icons/ai_blush_glow.png';
  static const aiLilac = 'assets/icons/ai_lilac_glow.png';
  static const bodyGlow = 'assets/icons/body_recovery_glow.png';
  static const sleep = 'assets/icons/sleep_crescent.png';
  static const mood = 'assets/icons/mood_wave.png';
  static const chevron = 'assets/icons/chevron_right.png';
  static const serviceLeaf = 'assets/icons/service_leaf.png';
  static const calendar = 'assets/icons/calendar.png';
  static const consultation = 'assets/icons/consultation.png';
  static const navMe = 'assets/icons/nav_me.png';
  static const navBaby = 'assets/icons/nav_baby.png';
  static const navSchedule = 'assets/icons/nav_schedule.png';
  static const navMore = 'assets/icons/nav_more.png';
}

class MomHomeScreen extends StatelessWidget {
  const MomHomeScreen({
    super.key,
    required this.data,
    this.callbacks = const MomHomeCallbacks(),
    this.currentNavigationIndex = 0,
  });

  final MomHomeData data;
  final MomHomeCallbacks callbacks;
  final int currentNavigationIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MomHomeColors.background,
      bottomNavigationBar: _MomBottomNavigation(
        selectedIndex: currentNavigationIndex,
        onTap: callbacks.onNavigationChanged,
      ),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _Header(data: data),
              const SizedBox(height: 14),
              _AiInsightCard(data: data, onTap: callbacks.onAiInsight),
              const SizedBox(height: 14),
              _SectionHeader(
                title: '今日泌乳',
                action: data.hasRecords ? '查看趋势 ›' : '记录说明 ›',
                onTap: callbacks.onLactationDetails,
              ),
              const SizedBox(height: 14),
              _LactationCard(
                data: data,
                onRecord: callbacks.onRecordLactation,
              ),
              const SizedBox(height: 14),
              _SectionHeader(
                title: '今日状态',
                action: data.hasRecords ? '今日已完成 3/3 · 查看趋势 ›' : '今日完成 0/3 · 开始记录 ›',
                onTap: data.hasRecords
                    ? callbacks.onRecoveryDetails
                    : callbacks.onRecordRecovery,
              ),
              const SizedBox(height: 14),
              _RecoveryStatus(data: data),
              const SizedBox(height: 14),
              _ExpertCompanionSection(data: data, callbacks: callbacks),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.data});

  final MomHomeData data;

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 58,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(data.greeting, style: Theme.of(context).textTheme.headlineSmall),
            Text(
              data.phaseLabel,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 11),
            ),
          ],
        ),
      );
}

class _AiInsightCard extends StatelessWidget {
  const _AiInsightCard({required this.data, this.onTap});

  final MomHomeData data;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => _TapSurface(
        onTap: onTap,
        borderRadius: 22,
        child: Container(
          height: 138,
          clipBehavior: Clip.antiAlias,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(22)),
            gradient: LinearGradient(
              colors: [Color(0xFFFFEDEA), Color(0xFFF7EFFC), Color(0xFFE7D5FA)],
              begin: Alignment.bottomLeft,
              end: Alignment.topRight,
            ),
          ),
          child: Stack(
            children: [
              Positioned(left: 0, bottom: 0, width: 130, child: Image.asset(_Assets.aiBlush)),
              Positioned(right: 0, top: 0, width: 116, child: Image.asset(_Assets.aiLilac)),
              Positioned(
                right: 16,
                top: 14,
                child: Container(
                  width: 48,
                  height: 48,
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                  child: ClipOval(child: Image.asset(_Assets.cozymateAvatar, fit: BoxFit.cover)),
                ),
              ),
              Positioned(
                left: 18,
                top: 12,
                right: 78,
                bottom: 12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.aiEyebrow,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: const Color(0xFF75569A),
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      data.aiTitle,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 17),
                    ),
                    const Spacer(),
                    Text(data.aiBody, style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              Positioned(
                right: 18,
                bottom: 14,
                child: Image.asset(_Assets.chevron, width: 18, height: 18),
              ),
            ],
          ),
        ),
      );
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title, required this.action, this.onTap});

  final String title;
  final String action;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 30,
        child: Row(
          children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const Spacer(),
            GestureDetector(
              onTap: onTap,
              behavior: HitTestBehavior.opaque,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Text(
                  action,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: MomHomeColors.rose,
                        fontWeight: FontWeight.w500,
                        fontSize: 11,
                      ),
                ),
              ),
            ),
          ],
        ),
      );
}

class _LactationCard extends StatelessWidget {
  const _LactationCard({required this.data, this.onRecord});

  final MomHomeData data;
  final VoidCallback? onRecord;

  @override
  Widget build(BuildContext context) => Container(
        height: 132,
        padding: const EdgeInsets.fromLTRB(16, 13, 16, 12),
        clipBehavior: Clip.antiAlias,
        decoration: const BoxDecoration(
          color: MomHomeColors.roseSoft,
          borderRadius: BorderRadius.all(Radius.circular(22)),
        ),
        child: Stack(
          children: [
            const Positioned(right: 8, top: -2, child: _DropletOutline()),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data.lactationValue,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 23),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: FilledButton(
                    onPressed: onRecord,
                    style: FilledButton.styleFrom(
                      backgroundColor: MomHomeColors.rose,
                      shape: const StadiumBorder(),
                      elevation: 0,
                    ),
                    child: const Text('+ 记录一次泌乳', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                ),
                const Spacer(),
                Text(data.lactationMeta, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ],
        ),
      );
}

class _RecoveryStatus extends StatelessWidget {
  const _RecoveryStatus({required this.data});

  final MomHomeData data;

  @override
  Widget build(BuildContext context) => Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _StatusCard(
                  title: '身体与精力',
                  value: data.bodyValue,
                  meta: data.bodyMeta,
                  background: MomHomeColors.cream,
                  decorationAsset: _Assets.bodyGlow,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _StatusCard(
                  title: '昨夜休息',
                  value: data.sleepValue,
                  meta: data.sleepMeta,
                  background: MomHomeColors.cream,
                  decorationAsset: _Assets.sleep,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 64,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const BoxDecoration(
              color: MomHomeColors.roseSoft,
              borderRadius: BorderRadius.all(Radius.circular(20)),
            ),
            child: Stack(
              children: [
                Positioned(right: 58, bottom: -8, width: 180, child: Image.asset(_Assets.mood)),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('今日心情', style: Theme.of(context).textTheme.bodySmall),
                      Text(data.moodValue, style: Theme.of(context).textTheme.titleMedium),
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: _MoodSelector(selectedIndex: data.moodSelection),
                ),
              ],
            ),
          ),
        ],
      );
}

class _StatusCard extends StatelessWidget {
  const _StatusCard({
    required this.title,
    required this.value,
    required this.meta,
    required this.background,
    required this.decorationAsset,
  });

  final String title;
  final String value;
  final String meta;
  final Color background;
  final String decorationAsset;

  @override
  Widget build(BuildContext context) => Container(
        height: 106,
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 10),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(20)),
        child: Stack(
          children: [
            Positioned(right: -8, bottom: -8, width: 78, child: Image.asset(decorationAsset)),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.bodySmall),
                const Spacer(),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 22),
                ),
                Text(meta, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ],
        ),
      );
}

class _MoodSelector extends StatelessWidget {
  const _MoodSelector({required this.selectedIndex});

  final int selectedIndex;

  @override
  Widget build(BuildContext context) {
    const labels = ['不太好', '一般', '不错'];
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(labels.length, (index) {
        final selected = index == selectedIndex;
        return Container(
          margin: EdgeInsets.only(left: index == 0 ? 0 : 6),
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
          decoration: BoxDecoration(
            color: selected ? MomHomeColors.rose : Colors.white.withOpacity(0.82),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            labels[index],
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: selected ? Colors.white : MomHomeColors.textSecondary,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                ),
          ),
        );
      }),
    );
  }
}

class _ExpertCompanionSection extends StatelessWidget {
  const _ExpertCompanionSection({required this.data, required this.callbacks});

  final MomHomeData data;
  final MomHomeCallbacks callbacks;

  @override
  Widget build(BuildContext context) {
    final content = <Widget>[
      Text('专家陪伴计划', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 14),
      _ExpertPlanEntry(onTap: callbacks.onExpertPlans),
    ];
    if (data.hasPurchasedPlan) {
      content.addAll([
        const SizedBox(height: 14),
        Row(
          children: [
            Text('我的陪伴计划', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 16)),
            const Spacer(),
            const _StatusPill(label: '1 项服务进行中', rose: true),
          ],
        ),
        const SizedBox(height: 14),
        _ActivePlanCard(data: data, callbacks: callbacks),
      ]);
    }
    return Container(
      padding: data.hasPurchasedPlan
          ? const EdgeInsets.symmetric(vertical: 8)
          : EdgeInsets.zero,
      decoration: data.hasPurchasedPlan
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: MomHomeColors.border.withOpacity(0.75)),
              gradient: const LinearGradient(
                colors: [Color(0xFFFFFBF8), Color(0xFFFCF7F5), Color(0xFFF5F0FA)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            )
          : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: content),
    );
  }
}

class _ExpertPlanEntry extends StatelessWidget {
  const _ExpertPlanEntry({this.onTap});

  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => _TapSurface(
        onTap: onTap,
        borderRadius: 21,
        child: Container(
          height: 84,
          padding: const EdgeInsets.fromLTRB(16, 15, 14, 15),
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(21),
            border: Border.all(color: MomHomeColors.border),
            gradient: const LinearGradient(
              colors: [Color(0xFFFFFDFC), Color(0xFFF0F8F4)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            boxShadow: const [BoxShadow(color: Color(0x0E725D55), blurRadius: 18, offset: Offset(0, 6))],
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(13),
                child: Image.asset(_Assets.expertGroup, width: 44, height: 44, fit: BoxFit.cover),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('让专业的人，陪你把问题解决', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 14)),
                    const SizedBox(height: 3),
                    Text(
                      '专家 + AI 持续服务，从分析问题到跟进改善，全程有人陪',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 9),
                    ),
                  ],
                ),
              ),
              Image.asset(_Assets.chevron, width: 18, height: 18),
            ],
          ),
        ),
      );
}

class _ActivePlanCard extends StatelessWidget {
  const _ActivePlanCard({required this.data, required this.callbacks});

  final MomHomeData data;
  final MomHomeCallbacks callbacks;

  @override
  Widget build(BuildContext context) => Container(
        height: 210,
        padding: const EdgeInsets.fromLTRB(20, 13, 16, 9),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(23),
          border: Border.all(color: const Color(0xFFE7DDD8)),
          gradient: const LinearGradient(
            colors: [Color(0xFFFFFDFB), Color(0xFFFFF8F5), Color(0xFFF3F8F5)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: const [BoxShadow(color: Color(0x0F6D5A54), blurRadius: 20, offset: Offset(0, 7))],
        ),
        child: Stack(
          children: [
            Positioned(right: -10, top: -18, width: 86, child: Opacity(opacity: 0.72, child: Image.asset(_Assets.serviceLeaf))),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: Text(data.planName, style: Theme.of(context).textTheme.headlineSmall)),
                    const _StatusPill(label: '服务进行中'),
                  ],
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Image.asset(_Assets.ibclcJamie, width: 44, height: 44, fit: BoxFit.cover),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(data.expertName, style: Theme.of(context).textTheme.titleMedium),
                        Text(data.expertCredential, style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _BenefitChip(
                        asset: _Assets.calendar,
                        label: '${data.supportDays} 天支持',
                        color: const Color(0xFFF5F0E8),
                      ),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: _BenefitChip(
                        asset: _Assets.consultation,
                        label: '剩余 ${data.consultationsRemaining} 次咨询',
                        color: const Color(0xFFF2EDF4),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Divider(height: 1, color: Color(0xFFE7DFDB)),
                const SizedBox(height: 3),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('本次未扣次数，可重新预约', style: Theme.of(context).textTheme.bodySmall),
                          GestureDetector(
                            onTap: callbacks.onServiceProgress,
                            child: Text(
                              '服务进度 ›',
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: const Color(0xFF8A6075),
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 88,
                      height: 35,
                      child: FilledButton(
                        onPressed: callbacks.onBookConsultation,
                        style: FilledButton.styleFrom(
                          backgroundColor: MomHomeColors.roseDeep,
                          padding: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Text('预约咨询', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      );
}

class _BenefitChip extends StatelessWidget {
  const _BenefitChip({required this.asset, required this.label, required this.color});

  final String asset;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        height: 42,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
        child: Row(
          children: [
            Container(
              width: 28,
              height: 28,
              padding: const EdgeInsets.all(6),
              decoration: const BoxDecoration(color: MomHomeColors.mint, shape: BoxShape.circle),
              child: Image.asset(asset),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: MomHomeColors.textPrimary,
                      fontWeight: FontWeight.w500,
                    ),
              ),
            ),
          ],
        ),
      );
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.label, this.rose = false});

  final String label;
  final bool rose;

  @override
  Widget build(BuildContext context) => Container(
        height: 28,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: rose ? const Color(0xFFF3E8EE) : MomHomeColors.mint,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: rose ? const Color(0xFFA64E72) : MomHomeColors.teal,
                fontWeight: FontWeight.w600,
              ),
        ),
      );
}

class _MomBottomNavigation extends StatelessWidget {
  const _MomBottomNavigation({required this.selectedIndex, this.onTap});

  final int selectedIndex;
  final ValueChanged<int>? onTap;

  @override
  Widget build(BuildContext context) {
    const labels = ['Me', 'Baby', 'Cozymate', 'Schedule', 'More'];
    const assets = [_Assets.navMe, _Assets.navBaby, _Assets.cozymateAvatar, _Assets.navSchedule, _Assets.navMore];
    return SafeArea(
      top: false,
      child: Container(
        height: 74,
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        decoration: const BoxDecoration(
          color: Color(0xFFFFFDFE),
          borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
          boxShadow: [BoxShadow(color: Color(0x0D443A3E), blurRadius: 16, offset: Offset(0, -3))],
        ),
        child: Row(
          children: List.generate(labels.length, (index) {
            final selected = index == selectedIndex;
            return Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => onTap?.call(index),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 36,
                      height: 32,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: selected ? const Color(0xFFF1E6FA) : Colors.transparent,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: index == 2
                          ? ClipOval(child: Image.asset(assets[index], width: 30, height: 30, fit: BoxFit.cover))
                          : Image.asset(assets[index], width: 24, height: 24),
                    ),
                    Text(
                      labels[index],
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: selected ? const Color(0xFF8248C8) : MomHomeColors.textMuted,
                            fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                          ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _TapSurface extends StatelessWidget {
  const _TapSurface({required this.child, required this.borderRadius, this.onTap});

  final Widget child;
  final double borderRadius;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(borderRadius),
          onTap: onTap,
          child: child,
        ),
      );
}

class _DropletOutline extends StatelessWidget {
  const _DropletOutline();

  @override
  Widget build(BuildContext context) => CustomPaint(
        size: const Size(52, 64),
        painter: _DropletPainter(),
      );
}

class _DropletPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.74)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3;
    final path = Path()
      ..moveTo(size.width / 2, 2)
      ..cubicTo(size.width * .74, size.height * .26, size.width * .92, size.height * .48, size.width * .92, size.height * .67)
      ..cubicTo(size.width * .92, size.height * .88, size.width * .75, size.height - 2, size.width / 2, size.height - 2)
      ..cubicTo(size.width * .25, size.height - 2, size.width * .08, size.height * .88, size.width * .08, size.height * .67)
      ..cubicTo(size.width * .08, size.height * .48, size.width * .26, size.height * .26, size.width / 2, 2)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
