import 'package:flutter/foundation.dart';

enum MomHomeViewState { initial, recorded, purchased }

class MomHomeCallbacks {
  const MomHomeCallbacks({
    this.onAiInsight,
    this.onRecordLactation,
    this.onLactationDetails,
    this.onRecoveryDetails,
    this.onRecordRecovery,
    this.onExpertPlans,
    this.onServiceProgress,
    this.onBookConsultation,
    this.onNavigationChanged,
  });

  final VoidCallback? onAiInsight;
  final VoidCallback? onRecordLactation;
  final VoidCallback? onLactationDetails;
  final VoidCallback? onRecoveryDetails;
  final VoidCallback? onRecordRecovery;
  final VoidCallback? onExpertPlans;
  final VoidCallback? onServiceProgress;
  final VoidCallback? onBookConsultation;
  final ValueChanged<int>? onNavigationChanged;
}

class MomHomeData {
  const MomHomeData({
    required this.viewState,
    required this.greeting,
    required this.phaseLabel,
    required this.aiEyebrow,
    required this.aiTitle,
    required this.aiBody,
    required this.lactationValue,
    required this.lactationMeta,
    required this.bodyValue,
    required this.bodyMeta,
    required this.sleepValue,
    required this.sleepMeta,
    required this.moodValue,
    this.moodSelection = 1,
    this.expertName = 'Jamie Lee',
    this.expertCredential = 'IBCLC',
    this.planName = '奶量管理',
    this.supportDays = 14,
    this.consultationsRemaining = 3,
  });

  final MomHomeViewState viewState;
  final String greeting;
  final String phaseLabel;
  final String aiEyebrow;
  final String aiTitle;
  final String aiBody;
  final String lactationValue;
  final String lactationMeta;
  final String bodyValue;
  final String bodyMeta;
  final String sleepValue;
  final String sleepMeta;
  final String moodValue;
  final int moodSelection;
  final String expertName;
  final String expertCredential;
  final String planName;
  final int supportDays;
  final int consultationsRemaining;

  bool get hasRecords => viewState != MomHomeViewState.initial;
  bool get hasPurchasedPlan => viewState == MomHomeViewState.purchased;

  factory MomHomeData.initial() => const MomHomeData(
        viewState: MomHomeViewState.initial,
        greeting: '下午好，Mia',
        phaseLabel: '产后第 21 天 · 恢复建立期',
        aiEyebrow: 'Cozymate · 等待你的首次记录',
        aiTitle: '记录一点点，\n我会更懂你的恢复状态',
        aiBody: '完成首次记录后，AI 会结合你的状态，生成每日恢复分析与行动建议。',
        lactationValue: '暂未记录',
        lactationMeta: '记录一次后，即可开始查看奶量与供需趋势',
        bodyValue: '待记录',
        bodyMeta: '约 10 秒 · 快速完成',
        sleepValue: '待记录',
        sleepMeta: '补充昨夜休息情况',
        moodValue: '今天感觉怎么样？',
      );

  factory MomHomeData.recorded() => const MomHomeData(
        viewState: MomHomeViewState.recorded,
        greeting: '下午好，Mia',
        phaseLabel: '产后第 21 天 · 恢复建立期',
        aiEyebrow: 'Cozymate · 基于今日完整记录',
        aiTitle: '昨夜休息偏少，\n今天先把恢复放在第一位',
        aiBody: '结合睡眠、精力和泌乳趋势，建议降低强度、优先补充休息，并留意乳房不适。',
        lactationValue: '110 ml',
        lactationMeta: '泵奶 2 次 · 亲喂 2 次',
        bodyValue: '70%',
        bodyMeta: '有力气 · 暂无明显不适',
        sleepValue: '4–5 小时',
        sleepMeta: '比前一晚少 1 小时',
        moodValue: '还算平稳',
      );

  factory MomHomeData.purchased() => MomHomeData.recorded().copyWith(
        viewState: MomHomeViewState.purchased,
      );

  MomHomeData copyWith({MomHomeViewState? viewState}) => MomHomeData(
        viewState: viewState ?? this.viewState,
        greeting: greeting,
        phaseLabel: phaseLabel,
        aiEyebrow: aiEyebrow,
        aiTitle: aiTitle,
        aiBody: aiBody,
        lactationValue: lactationValue,
        lactationMeta: lactationMeta,
        bodyValue: bodyValue,
        bodyMeta: bodyMeta,
        sleepValue: sleepValue,
        sleepMeta: sleepMeta,
        moodValue: moodValue,
        moodSelection: moodSelection,
        expertName: expertName,
        expertCredential: expertCredential,
        planName: planName,
        supportDays: supportDays,
        consultationsRemaining: consultationsRemaining,
      );
}
